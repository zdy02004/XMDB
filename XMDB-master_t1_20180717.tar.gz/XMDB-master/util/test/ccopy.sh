 cp a.out ../../mem_date_index_ctl/test/test_mem_mvcc/test
